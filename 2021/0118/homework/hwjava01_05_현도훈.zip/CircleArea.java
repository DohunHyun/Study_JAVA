package com.java.first;

public class CircleArea {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double space = 5*5*Math.PI;
		System.out.printf("반지름이 5cm인 원의 넓이는 %.1f cm^2입니다.", space);
	}

}
